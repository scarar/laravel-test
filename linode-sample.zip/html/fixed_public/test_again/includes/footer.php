<div class="clear"></div>
        <footer>
            <span>&#169; Copyright <?php echo date('Y'); ?></span>
            <div class="validator">
                <a href="https://jigsaw.w3.org/css-validator/check/referer">
                    <img style="border:0;width:88px;height:31px"
                         src="https://jigsaw.w3.org/css-validator/images/vcss"
                         alt="Valid CSS">
                </a>
            </div>
        </footer>
    </div>
</body>
</html>